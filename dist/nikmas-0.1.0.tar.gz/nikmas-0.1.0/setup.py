# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nikmas', 'nikmas.utils']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'nikmas',
    'version': '0.1.0',
    'description': 'Collection of useful utils for python projects.',
    'long_description': '# Nikmas\' library\n\nCollection of useful utils for python projects.\n\n## Installation\n\n```\npip install nikmas\n```\n\n## Get started\n\n### Get all custom class attribute names\n\n```Python\nfrom nikmas.utils import get_custom_attribute_names\n\n\nclass Custom:\n    a = 1\n    b = 2\n    c = 3\n\n\nattrs_from_class_object_itself = get_custom_attribute_names(Custom)\n# result -> ["a", "b", "c"]\n\ninstance = Custom()\nattrs_from_class_instance = get_custom_attribute_names(instance)\n# result -> ["a", "b", "c"]\n```\n',
    'author': 'Nikita Maslov',
    'author_email': 'maslov.n.e@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/nikmas-dev/Nikmas_library',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
